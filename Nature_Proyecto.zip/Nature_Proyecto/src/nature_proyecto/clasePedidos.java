package nature_proyecto;

public class clasePedidos {
    
    private String idPedido;
    private String idClientePedido;
    private String descripcionPedido;
    private String costoPedido;
    private String fechaPedido;

    public String getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(String idPedido) {
        this.idPedido = idPedido;
    }

    public String getIdClientePedido() {
        return idClientePedido;
    }

    public void setIdClientePedido(String clientePedido) {
        this.idClientePedido = clientePedido;
    }

    public String getDescripcionPedido() {
        return descripcionPedido;
    }

    public void setDescripcionPedido(String descripcionPedido) {
        this.descripcionPedido = descripcionPedido;
    }

    public String getCostoPedido() {
        return costoPedido;
    }

    public void setCostoPedido(String costoPedido) {
        this.costoPedido = costoPedido;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }
    
}