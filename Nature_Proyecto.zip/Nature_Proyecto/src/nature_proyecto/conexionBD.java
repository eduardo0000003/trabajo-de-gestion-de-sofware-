package nature_proyecto;

import java.sql.*;
import javax.swing.JOptionPane;

public class conexionBD {
    
    private Connection con=null;
    
    public void conexionBD(){
        conectar();
    }
    
    public void conectar(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/nature?user=root&password=");
            
            System.out.println("Conectado a la base de datos de mysql.");
            System.out.println("Ya está listo.");
        }catch(ClassNotFoundException cnfe){
            System.out.println(cnfe.getMessage());
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
        }
    }
    
    public int idUnicaCliente(){
        int idUnica=1 + (int) (Math.random() * 100);
        ResultSet rs=consultarIdCliente();
        try{
            while(rs.next()){
                if(rs.getString("idCliente")==String.valueOf(idUnica)){
                    idUnica = 1 + (int) (Math.random() * 100);
                }else{
                    break;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return idUnica;
    }
    
    public ResultSet consultarIdCliente(){
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT idCliente FROM clientes";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public void registrarUsuario(claseClientes c){
        
        try{
            PreparedStatement ps=con.prepareStatement("INSERT INTO clientes VALUES(?,?,?,?,?,?,?,?)");
            ps.setString(1, c.getIdCliente());
            ps.setString(2, c.getNombreCliente());
            ps.setString(3, c.getFechaNacimientoCliente());
            ps.setString(4, c.getSexoCliente());
            ps.setString(5, c.getCorreoCliente());
            ps.setString(6, c.getTelefonoCliente());
            ps.setString(7, c.getDireccionCliente());
            ps.setString(8, c.getContraseñaCliente());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Se ha insertado el registro con éxito.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.getStackTrace();
        }
    }
    
    public void registrarEmpleado(claseEmpleados e){
        
        try{
            PreparedStatement ps=con.prepareStatement("INSERT INTO empleados VALUES(?,?,?,?)");
            ps.setString(1, e.getIdEmpleado());
            ps.setString(2, e.getNombreEmpleado());
            ps.setString(3, e.getCargoEmpleado());
            ps.setString(4, e.getContraseñaEmpleado());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Se ha insertado el registro con éxito.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.getStackTrace();
        }
    }
    
    public int comprobarNombreCliente(claseClientes c){
        int cNC=0;
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT nombreCliente FROM clientes";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
            while(rs.next()){
                if(rs.getString("nombreCliente").equals(c.getNombreCliente())){
                   cNC=1;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return cNC;
    }
    
    public int comprobarContraseñaCliente(claseClientes c){
        int cCC=0;
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT contraseñaCliente FROM clientes";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
            while(rs.next()){
                if(rs.getString("contraseñaCliente").equals(c.getContraseñaCliente())){
                   cCC=1;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return cCC;
    }
    
    public int idUnicaEmpleado(){
        int idUnica=1 + (int) (Math.random() * 100);
        ResultSet rs=consultarIdEmpleado();
        try{
            while(rs.next()){
                if(rs.getString("idEmpleado")==String.valueOf(idUnica)){
                    idUnica = 1 + (int) (Math.random() * 100);
                }else{
                    break;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return idUnica;
    }
    
    public ResultSet consultarIdEmpleado(){
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT idEmpleado FROM empleados";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public int comprobarNombreEmpleado(claseEmpleados e){
        int cNE=0;
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT nombreEmpleado FROM empleados";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
            while(rs.next()){
                if(rs.getString("nombreEmpleado").equals(e.getNombreEmpleado())){
                   cNE=1;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return cNE;
    }
    
    public int comprobarContraseñaEmpleado(claseEmpleados e){
        int cCE=0;
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT contraseñaEmpleado FROM empleados";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
            while(rs.next()){
                if(rs.getString("contraseñaEmpleado").equals(e.getContraseñaEmpleado())){
                   cCE=1;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return cCE;
    }
    
    public int comprobarNombreAdministrador(String s){
        int cNA=0;
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT nombreAdministrador FROM administradores";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
            while(rs.next()){
                if(rs.getString("nombreAdministrador").equals(s)){
                   cNA=1;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return cNA;
    }
    
    public int comprobarContraseñaAdministrador(String s){
        int cCA=0;
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT contraseñaAdministrador FROM administradores";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
            while(rs.next()){
                if(rs.getString("contraseñaAdministrador").equals(s)){
                   cCA=1;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return cCA;
    }
    
    public ResultSet mostrarProductos(String s){
        ResultSet rs=null;
        try{
            String sentenciaSQL="SELECT nombreProducto, precioProducto FROM productos WHERE categoriaProducto = ?";
            PreparedStatement stm=con.prepareStatement(sentenciaSQL);
            stm.setString(1,s);
            rs=stm.executeQuery();
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public int idUnicaPedido(){
        int idUnica=1 + (int) (Math.random() * 100);
        ResultSet rs=consultarIdPedido();
        try{
            while(rs.next()){
                if(rs.getString("idPedido")==String.valueOf(idUnica)){
                    idUnica = 1 + (int) (Math.random() * 100);
                }else{
                    break;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return idUnica;
    }
    
    public ResultSet consultarIdPedido(){
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT idPedido FROM pedidos";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public void registrarPedido(clasePedidos p){
        
        try{
            PreparedStatement ps=con.prepareStatement("INSERT INTO pedidos VALUES(?,?,?,?,?)");
            ps.setString(1, p.getIdPedido());
            ps.setString(2, p.getIdClientePedido());
            ps.setString(3, p.getDescripcionPedido());
            ps.setString(4, p.getCostoPedido());
            ps.setString(5, p.getFechaPedido());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Se ha insertado el registro con éxito.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.getStackTrace();
        }
    }
    
    public int encontrarIdCliente(String a, String b){
        int id=0;
        ResultSet rs=null;
        String sentenciaSQL="SELECT idCliente FROM clientes WHERE nombreCliente=? AND contraseñaCliente=?";
        try{
            PreparedStatement stm=con.prepareStatement(sentenciaSQL);
            stm.setString(1, a);
            stm.setString(2, b);
            rs=stm.executeQuery();
            while(rs.next()){
                id=rs.getInt("idCliente");
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return id;
    }
    
    public ResultSet consultarTodosPedidos(){
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT * FROM pedidos";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public ResultSet pedidosCliente(String a){
        ResultSet rs=null;
        String sentenciaSQL="SELECT idPedido, idClientePedido, descripcionPedido, costoPedido, fechaPedido FROM pedidos WHERE idClientePedido=?";
        try{
            PreparedStatement stm=con.prepareStatement(sentenciaSQL);
            stm.setString(1, a);
            rs=stm.executeQuery();
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public void insertarProducto(claseProductos p){
        
        try{
            PreparedStatement ps=con.prepareStatement("INSERT INTO productos VALUES(?,?,?,?,?)");
            ps.setString(1, p.getIdProducto());
            ps.setString(2, p.getNombreProducto());
            ps.setString(3, p.getCategoriaProducto());
            ps.setString(4, p.getCantidadProducto());
            ps.setString(5, p.getPrecioProducto());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Se ha insertado el registro con éxito.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.getStackTrace();
        }
    }
    
    public void eliminarProducto(claseProductos p){
        
        try{
            PreparedStatement ps=con.prepareStatement("DELETE FROM productos WHERE idProducto=?");
            ps.setString(1, p.getIdProducto());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Se ha eliminado el registro con éxito.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.getStackTrace();
        }
    }
    
    public int idUnicaProducto(){
        int idUnica=1 + (int) (Math.random() * 100);
        ResultSet rs=consultarIdProducto();
        try{
            while(rs.next()){
                if(rs.getString("idProducto")==String.valueOf(idUnica)){
                    idUnica = 1 + (int) (Math.random() * 100);
                }else{
                    break;
                }
            }
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return idUnica;
    }
    
    public ResultSet consultarIdProducto(){
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT idProducto FROM productos";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public ResultSet consultarTodosProductos(){
        ResultSet rs=null;
        Statement stm;
        String sentenciaSQL="SELECT * FROM productos";
        try{
            stm=con.createStatement();
            rs=stm.executeQuery(sentenciaSQL);
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
        return rs;
    }
    
    public void modificarProductos(claseProductos cP){
        try{
            PreparedStatement ps=con.prepareStatement("UPDATE productos SET nombreProducto=?, categoriaProducto=?, cantidadProducto=?, precioProducto=? WHERE idProducto=?");
            ps.setString(1, cP.getNombreProducto());
            ps.setString(2, cP.getCategoriaProducto());
            ps.setString(3, cP.getCantidadProducto());
            ps.setString(4, cP.getPrecioProducto());
            ps.setString(5, cP.getIdProducto());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Modificacion exitosa.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.printStackTrace();
        }
    }
    
    public void modificarUsuario(claseClientes c){
        
        try{
            PreparedStatement ps=con.prepareStatement("UPDATE clientes SET nombreCliente=?, fechaNacimientoCliente=?, sexoCliente=?, correoCliente=?, telefonoCliente=?, direccionCliente=?, contraseñaCliente=? WHERE idCliente=?");
            ps.setString(1, c.getNombreCliente());
            ps.setString(2, c.getFechaNacimientoCliente());
            ps.setString(3, c.getSexoCliente());
            ps.setString(4, c.getCorreoCliente());
            ps.setString(5, c.getTelefonoCliente());
            ps.setString(6, c.getDireccionCliente());
            ps.setString(7, c.getContraseñaCliente());
            ps.setString(8, c.getIdCliente());
            int filasAfectadas=ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Modificacion exitosa.");
        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
            sqle.getStackTrace();
        }
    }
    
}