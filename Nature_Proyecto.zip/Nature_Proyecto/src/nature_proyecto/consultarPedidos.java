package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;

public class consultarPedidos extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public consultarPedidos() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        tituloLabel = new javax.swing.JLabel();
        tablaDinamicaScroll = new javax.swing.JScrollPane();
        tablaPedidos = new javax.swing.JTable();
        pedidosLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        mostrarUsuarioPanel = new javax.swing.JPanel();
        mostrarUsuarioLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();
        actualizarButtonPanel = new javax.swing.JPanel();
        actualizarButtonLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        logoLabel.setText("jLabel1");
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Theo Vital");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(380, 80, 220, 50);

        tablaPedidos.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        tablaPedidos.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        tablaPedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Pedido.", "ID Cliente.", "Descripcion", "Costo.", "Fecha."
            }
        ));
        tablaPedidos.setGridColor(new java.awt.Color(0, 0, 0));
        tablaDinamicaScroll.setViewportView(tablaPedidos);

        fondoPrincipal.add(tablaDinamicaScroll);
        tablaDinamicaScroll.setBounds(20, 200, 770, 220);

        pedidosLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        pedidosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pedidosLabel.setText("Consulta tus pedidos.");
        fondoPrincipal.add(pedidosLabel);
        pedidosLabel.setBounds(320, 160, 180, 30);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        mostrarUsuarioPanel.setBackground(new java.awt.Color(0, 168, 234));
        mostrarUsuarioPanel.setLayout(null);

        mostrarUsuarioLabel.setBackground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        mostrarUsuarioLabel.setForeground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrarUsuarioLabel.setText("En espera...");
        mostrarUsuarioPanel.add(mostrarUsuarioLabel);
        mostrarUsuarioLabel.setBounds(0, 0, 160, 30);

        headerPanel.add(mostrarUsuarioPanel);
        mostrarUsuarioPanel.setBounds(620, 20, 160, 30);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(30, 440, 100, 30);

        actualizarButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        actualizarButtonPanel.setLayout(null);

        actualizarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        actualizarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        actualizarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        actualizarButtonLabel.setText("Actualizar.");
        actualizarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                actualizarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                actualizarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                actualizarButtonLabelMouseExited(evt);
            }
        });
        actualizarButtonPanel.add(actualizarButtonLabel);
        actualizarButtonLabel.setBounds(0, 0, 90, 30);

        fondoPrincipal.add(actualizarButtonPanel);
        actualizarButtonPanel.setBounds(350, 440, 90, 30);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        menuDinamico mD=new menuDinamico();
        mD.setVisible(true);
        mD.obtenerDatos(mostrarUsuarioLabel.getText());
        switch(mostrarUsuarioLabel.getText()){
            case "Empleado.":
                mD.Cambio("Empleado.", "");
                break;
            case "Administrador.":
                 mD.Cambio("Administrador.", "");
                break;
            default:
                 mD.Cambio("Cliente.", mostrarUsuarioLabel.getText());
                break;
        }
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    private void actualizarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_actualizarButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        if(mostrarUsuarioLabel.getText().equals("Empleado.") || mostrarUsuarioLabel.getText().equals("Administrador.")){
            DefaultTableModel modelo=new DefaultTableModel();
    tablaPedidos.setModel(modelo);
    ResultSet rs=cBD.consultarTodosPedidos();
    try{
        ResultSetMetaData rsmd=rs.getMetaData();
        int columnas=rsmd.getColumnCount();
        modelo.addColumn("ID Pedido.");
        modelo.addColumn("ID Cliente.");
        modelo.addColumn("Descripcion.");
        modelo.addColumn("Costo.");
        modelo.addColumn("Fecha.");
        while(rs.next()){
            Object [] filas=new Object [columnas];
            for(int i=0;i<columnas;i++){
                filas[i]=rs.getObject(i+1);
            }
            modelo.addRow(filas);
        }
    }catch(SQLException sqle){
        System.out.println(sqle.getMessage());
            sqle.printStackTrace();
    }
        }else{
            DefaultTableModel modelo=new DefaultTableModel();
    tablaPedidos.setModel(modelo);
    ResultSet rs=cBD.pedidosCliente(mostrarUsuarioLabel.getText());
    try{
        ResultSetMetaData rsmd=rs.getMetaData();
        int columnas=rsmd.getColumnCount();
        modelo.addColumn("ID Pedido.");
        modelo.addColumn("ID Cliente.");
        modelo.addColumn("Descripcion.");
        modelo.addColumn("Costo.");
        modelo.addColumn("Fecha.");
        while(rs.next()){
            Object [] filas=new Object [columnas];
            for(int i=0;i<columnas;i++){
                filas[i]=rs.getObject(i+1);
            }
            modelo.addRow(filas);
        }
    }catch(SQLException sqle){
        System.out.println(sqle.getMessage());
            sqle.printStackTrace();
    }
        }
    }//GEN-LAST:event_actualizarButtonLabelMouseClicked

    private void actualizarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_actualizarButtonLabelMouseEntered
        actualizarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_actualizarButtonLabelMouseEntered

    private void actualizarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_actualizarButtonLabelMouseExited
        actualizarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_actualizarButtonLabelMouseExited

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new consultarPedidos().setVisible(true);
            }
        });
    }
    
    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
    }
    
    public void obtenerDatos(String i){
        mostrarUsuarioLabel.setText(i);
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel actualizarButtonLabel;
    private javax.swing.JPanel actualizarButtonPanel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel mostrarUsuarioLabel;
    private javax.swing.JPanel mostrarUsuarioPanel;
    private javax.swing.JLabel pedidosLabel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JScrollPane tablaDinamicaScroll;
    private javax.swing.JTable tablaPedidos;
    private javax.swing.JLabel tituloLabel;
    // End of variables declaration//GEN-END:variables
}