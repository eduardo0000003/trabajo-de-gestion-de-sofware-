package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;

public class contactosNature extends javax.swing.JFrame {
    
    int xMouse, yMouse;
    
    public contactosNature() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        tituloLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();
        nosotrosLabel = new javax.swing.JLabel();
        direccionLabel = new javax.swing.JLabel();
        direccionContenidoLabel = new javax.swing.JLabel();
        telefonoLabel = new javax.swing.JLabel();
        propioTelefonoLabel = new javax.swing.JLabel();
        facebookImagenLabel = new javax.swing.JLabel();
        instagramImagenLabel = new javax.swing.JLabel();
        twitterImagenLabel = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        mostrarUsuarioPanel = new javax.swing.JPanel();
        mostrarUsuarioLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        logoLabel.setText("jLabel1");
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Theo Vital");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(380, 80, 220, 50);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(70, 440, 100, 30);

        nosotrosLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        nosotrosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nosotrosLabel.setText("Acerca de nosotros:");
        fondoPrincipal.add(nosotrosLabel);
        nosotrosLabel.setBounds(320, 200, 190, 30);

        direccionLabel.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        direccionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        direccionLabel.setText("Direccion:");
        fondoPrincipal.add(direccionLabel);
        direccionLabel.setBounds(200, 250, 90, 20);

        direccionContenidoLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        direccionContenidoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        direccionContenidoLabel.setText("C. Cap. Francisco de Ibarra 1206, Nueva Vizcaya, 34080");
        fondoPrincipal.add(direccionContenidoLabel);
        direccionContenidoLabel.setBounds(280, 250, 370, 20);

        telefonoLabel.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        telefonoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        telefonoLabel.setText("Número de telefono:");
        fondoPrincipal.add(telefonoLabel);
        telefonoLabel.setBounds(290, 290, 130, 20);

        propioTelefonoLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        propioTelefonoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        propioTelefonoLabel.setText("618 810 2264");
        fondoPrincipal.add(propioTelefonoLabel);
        propioTelefonoLabel.setBounds(430, 290, 110, 20);

        facebookImagenLabel.setText("facebook");
        fondoPrincipal.add(facebookImagenLabel);
        facebookImagenLabel.setBounds(230, 360, 50, 50);

        instagramImagenLabel.setText("insta");
        fondoPrincipal.add(instagramImagenLabel);
        instagramImagenLabel.setBounds(410, 360, 50, 50);

        twitterImagenLabel.setText("twitter");
        fondoPrincipal.add(twitterImagenLabel);
        twitterImagenLabel.setBounds(580, 360, 50, 50);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        mostrarUsuarioPanel.setBackground(new java.awt.Color(0, 168, 234));
        mostrarUsuarioPanel.setLayout(null);

        mostrarUsuarioLabel.setBackground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        mostrarUsuarioLabel.setForeground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrarUsuarioLabel.setText("En espera...");
        mostrarUsuarioPanel.add(mostrarUsuarioLabel);
        mostrarUsuarioLabel.setBounds(0, 0, 160, 30);

        headerPanel.add(mostrarUsuarioPanel);
        mostrarUsuarioPanel.setBounds(620, 20, 160, 30);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        menuDinamico mD=new menuDinamico();
        mD.setVisible(true);
            if(mostrarUsuarioLabel.getText().equals("Empleado.") || mostrarUsuarioLabel.getText().equals("Administrador.")){
                mD.Cambio(mostrarUsuarioLabel.getText(), mostrarUsuarioLabel.getText());
            }else{
                mD.Cambio("Cliente.", mostrarUsuarioLabel.getText());
            }
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new contactosNature().setVisible(true);
            }
        });
    }
    
    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\facebookLogo.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(facebookImagenLabel.getWidth(), facebookImagenLabel.getHeight(), Image.SCALE_DEFAULT));
            facebookImagenLabel.setIcon(icono);
            facebookImagenLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\instagramLogo.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(instagramImagenLabel.getWidth(), instagramImagenLabel.getHeight(), Image.SCALE_DEFAULT));
            instagramImagenLabel.setIcon(icono);
            instagramImagenLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\twitterLogo.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(twitterImagenLabel.getWidth(), twitterImagenLabel.getHeight(), Image.SCALE_DEFAULT));
            twitterImagenLabel.setIcon(icono);
            twitterImagenLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
        
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }
    
    public void obtenerDatos(String i){
        mostrarUsuarioLabel.setText(i);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel direccionContenidoLabel;
    private javax.swing.JLabel direccionLabel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel facebookImagenLabel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel instagramImagenLabel;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel mostrarUsuarioLabel;
    private javax.swing.JPanel mostrarUsuarioPanel;
    private javax.swing.JLabel nosotrosLabel;
    private javax.swing.JLabel propioTelefonoLabel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JLabel telefonoLabel;
    private javax.swing.JLabel tituloLabel;
    private javax.swing.JLabel twitterImagenLabel;
    // End of variables declaration//GEN-END:variables
}