package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;

public class gestionarCatalogo extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public gestionarCatalogo() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
        actualizarTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        tituloLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        mostrarUsuarioPanel = new javax.swing.JPanel();
        mostrarUsuarioLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        catalogoTabla = new javax.swing.JTable();
        nombreLabel = new javax.swing.JLabel();
        categoriaLabel = new javax.swing.JLabel();
        cantidadLabel = new javax.swing.JLabel();
        precioLabel = new javax.swing.JLabel();
        agregarButtonPanel = new javax.swing.JPanel();
        agregarButtonLabel = new javax.swing.JLabel();
        eliminarButtonPanel = new javax.swing.JPanel();
        eliminarButtonLabel = new javax.swing.JLabel();
        categoriaField = new javax.swing.JTextField();
        nombreField = new javax.swing.JTextField();
        cantidadField = new javax.swing.JTextField();
        precioField = new javax.swing.JTextField();
        modificarButtonPanel = new javax.swing.JPanel();
        modificarButtonLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        logoLabel.setText("jLabel1");
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Catálogo");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(380, 80, 230, 60);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        mostrarUsuarioPanel.setBackground(new java.awt.Color(0, 168, 234));
        mostrarUsuarioPanel.setLayout(null);

        mostrarUsuarioLabel.setBackground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        mostrarUsuarioLabel.setForeground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrarUsuarioLabel.setText("En espera...");
        mostrarUsuarioPanel.add(mostrarUsuarioLabel);
        mostrarUsuarioLabel.setBounds(0, 0, 160, 30);

        headerPanel.add(mostrarUsuarioPanel);
        mostrarUsuarioPanel.setBounds(620, 20, 160, 30);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(30, 440, 100, 30);

        catalogoTabla.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        catalogoTabla.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        catalogoTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID.", "Nombre.", "Categoria.", "Cantidad.", "Precio."
            }
        ));
        catalogoTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                catalogoTablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(catalogoTabla);

        fondoPrincipal.add(jScrollPane1);
        jScrollPane1.setBounds(30, 170, 740, 140);

        nombreLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        nombreLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nombreLabel.setText("Nombre: ");
        fondoPrincipal.add(nombreLabel);
        nombreLabel.setBounds(60, 340, 60, 19);

        categoriaLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        categoriaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        categoriaLabel.setText("Categoria:");
        fondoPrincipal.add(categoriaLabel);
        categoriaLabel.setBounds(50, 390, 70, 19);

        cantidadLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        cantidadLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cantidadLabel.setText("Cantidad:");
        fondoPrincipal.add(cantidadLabel);
        cantidadLabel.setBounds(410, 340, 70, 19);

        precioLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        precioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        precioLabel.setText("Precio:");
        fondoPrincipal.add(precioLabel);
        precioLabel.setBounds(410, 390, 50, 19);

        agregarButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        agregarButtonPanel.setLayout(null);

        agregarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        agregarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        agregarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        agregarButtonLabel.setText("Agregar.");
        agregarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                agregarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                agregarButtonLabelMouseExited(evt);
            }
        });
        agregarButtonPanel.add(agregarButtonLabel);
        agregarButtonLabel.setBounds(0, 0, 90, 30);

        fondoPrincipal.add(agregarButtonPanel);
        agregarButtonPanel.setBounds(260, 440, 90, 30);

        eliminarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        eliminarButtonPanel.setLayout(null);

        eliminarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        eliminarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        eliminarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        eliminarButtonLabel.setText("Eliminar.");
        eliminarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                eliminarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                eliminarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                eliminarButtonLabelMouseExited(evt);
            }
        });
        eliminarButtonPanel.add(eliminarButtonLabel);
        eliminarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(eliminarButtonPanel);
        eliminarButtonPanel.setBounds(610, 440, 100, 30);

        categoriaField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(categoriaField);
        categoriaField.setBounds(130, 390, 190, 20);

        nombreField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(nombreField);
        nombreField.setBounds(130, 340, 190, 20);

        cantidadField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(cantidadField);
        cantidadField.setBounds(490, 340, 190, 20);

        precioField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(precioField);
        precioField.setBounds(470, 390, 190, 20);

        modificarButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        modificarButtonPanel.setLayout(null);

        modificarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        modificarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        modificarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        modificarButtonLabel.setText("Modificar.");
        modificarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                modificarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                modificarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                modificarButtonLabelMouseExited(evt);
            }
        });
        modificarButtonPanel.add(modificarButtonLabel);
        modificarButtonLabel.setBounds(0, 0, 90, 30);

        fondoPrincipal.add(modificarButtonPanel);
        modificarButtonPanel.setBounds(440, 440, 90, 30);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        menuDinamico mD=new menuDinamico();
        mD.setVisible(true);
        mD.obtenerDatos(mostrarUsuarioLabel.getText());
        mD.Cambio(mostrarUsuarioLabel.getText(), mostrarUsuarioLabel.getText());
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    private void agregarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        if(nombreField.getText().isBlank() || categoriaField.getText().isBlank() || precioField.getText().isBlank() || cantidadField.getText().isBlank()){
            JOptionPane.showMessageDialog(null,"Porfavor rellena los campos.");
        }else{
            claseProductos cP=new claseProductos();
            cP.setIdProducto(String.valueOf(cBD.idUnicaProducto()));
            cP.setNombreProducto(nombreField.getText());
            cP.setCategoriaProducto(categoriaField.getText());
            cP.setCantidadProducto(cantidadField.getText());
            cP.setPrecioProducto(precioField.getText());
            
            cBD.insertarProducto(cP);
            actualizarTabla();
            limpiarFields();
        }
    }//GEN-LAST:event_agregarButtonLabelMouseClicked

    private void agregarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarButtonLabelMouseEntered
        agregarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_agregarButtonLabelMouseEntered

    private void agregarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarButtonLabelMouseExited
        agregarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_agregarButtonLabelMouseExited

    private void eliminarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        int fila=catalogoTabla.getSelectedRow();
        if(fila==-1){
            JOptionPane.showMessageDialog(null,"No has seleccionado un elemento.");
        }else{
            int proximoEliminado=0;
            claseProductos cP=new claseProductos();
            cP.setIdProducto(String.valueOf(catalogoTabla.getValueAt(fila, 0)));
            cBD.eliminarProducto(cP);
            actualizarTabla();
            limpiarFields();
        }
    }//GEN-LAST:event_eliminarButtonLabelMouseClicked

    private void eliminarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarButtonLabelMouseEntered
        eliminarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_eliminarButtonLabelMouseEntered

    private void eliminarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarButtonLabelMouseExited
        eliminarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_eliminarButtonLabelMouseExited

    private void modificarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modificarButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        int fila=catalogoTabla.getSelectedRow();
        if(fila==-1){
            JOptionPane.showMessageDialog(null,"No has seleccionado un elemento.");
        }else{
            claseProductos cP=new claseProductos();
            cP.setIdProducto(String.valueOf(catalogoTabla.getValueAt(fila, 0)));
            cP.setNombreProducto(nombreField.getText());
            cP.setCategoriaProducto(categoriaField.getText());
            cP.setCantidadProducto(cantidadField.getText());
            cP.setPrecioProducto(precioField.getText());
            cBD.modificarProductos(cP);
            actualizarTabla();
            limpiarFields();
        }
    }//GEN-LAST:event_modificarButtonLabelMouseClicked

    private void modificarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modificarButtonLabelMouseEntered
        modificarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_modificarButtonLabelMouseEntered

    private void modificarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_modificarButtonLabelMouseExited
        modificarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_modificarButtonLabelMouseExited

    private void catalogoTablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_catalogoTablaMouseClicked
        int fila=catalogoTabla.getSelectedRow();
        if(fila==-1){
        }else{
            nombreField.setText(String.valueOf(catalogoTabla.getValueAt(fila, 1)));
            categoriaField.setText(String.valueOf(catalogoTabla.getValueAt(fila, 2)));
            cantidadField.setText(String.valueOf(catalogoTabla.getValueAt(fila, 3)));
            precioField.setText(String.valueOf(catalogoTabla.getValueAt(fila, 4)));
        }
    }//GEN-LAST:event_catalogoTablaMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gestionarCatalogo().setVisible(true);
            }
        });
    }
    
    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
        
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }
    
    public void obtenerDatos(String i){
        mostrarUsuarioLabel.setText(i);
    }
    
    public void actualizarTabla(){
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        DefaultTableModel modelo=new DefaultTableModel();
    catalogoTabla.setModel(modelo);
    ResultSet rs=cBD.consultarTodosProductos();
    try{
        ResultSetMetaData rsmd=rs.getMetaData();
        int columnas=rsmd.getColumnCount();
        modelo.addColumn("ID.");
        modelo.addColumn("Nombre");
        modelo.addColumn("Categoría.");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Precio.");
        while(rs.next()){
            Object [] filas=new Object [columnas];
            for(int i=0;i<columnas;i++){
                filas[i]=rs.getObject(i+1);
            }
            modelo.addRow(filas);
        }
    }catch(SQLException sqle){
        System.out.println(sqle.getMessage());
            sqle.printStackTrace();
    }
    }
    
    public void limpiarFields(){
        nombreField.setText("");
        categoriaField.setText("");
        cantidadField.setText("");
        precioField.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel agregarButtonLabel;
    private javax.swing.JPanel agregarButtonPanel;
    private javax.swing.JTextField cantidadField;
    private javax.swing.JLabel cantidadLabel;
    private javax.swing.JTable catalogoTabla;
    private javax.swing.JTextField categoriaField;
    private javax.swing.JLabel categoriaLabel;
    private javax.swing.JLabel eliminarButtonLabel;
    private javax.swing.JPanel eliminarButtonPanel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel modificarButtonLabel;
    private javax.swing.JPanel modificarButtonPanel;
    private javax.swing.JLabel mostrarUsuarioLabel;
    private javax.swing.JPanel mostrarUsuarioPanel;
    private javax.swing.JTextField nombreField;
    private javax.swing.JLabel nombreLabel;
    private javax.swing.JTextField precioField;
    private javax.swing.JLabel precioLabel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JLabel tituloLabel;
    // End of variables declaration//GEN-END:variables
}