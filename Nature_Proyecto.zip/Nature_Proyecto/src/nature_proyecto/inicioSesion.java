package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;

public class inicioSesion extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public inicioSesion() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        tituloLabel = new javax.swing.JLabel();
        inicioSesionLabel = new javax.swing.JLabel();
        usuarioLabel = new javax.swing.JLabel();
        usuarioField = new javax.swing.JTextField();
        usuarioSeparador = new javax.swing.JSeparator();
        contraseñaLabel = new javax.swing.JLabel();
        contraseñaField = new javax.swing.JPasswordField();
        contraseñaSeparador = new javax.swing.JSeparator();
        logoMainLabel = new javax.swing.JLabel();
        loginStartImage = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        entrarButtonPanel = new javax.swing.JPanel();
        entrarButtonLabel = new javax.swing.JLabel();
        registrarseButtonPanel = new javax.swing.JPanel();
        registrarseButtonLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Theo Vital");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(190, 80, 220, 40);

        inicioSesionLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        inicioSesionLabel.setText("Inicio de sesión.");
        fondoPrincipal.add(inicioSesionLabel);
        inicioSesionLabel.setBounds(60, 200, 130, 20);

        usuarioLabel.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        usuarioLabel.setText("Usuario.");
        fondoPrincipal.add(usuarioLabel);
        usuarioLabel.setBounds(60, 240, 60, 20);

        usuarioField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        usuarioField.setForeground(new java.awt.Color(204, 204, 204));
        usuarioField.setText("Ingrese su nombre de usuario.");
        usuarioField.setBorder(null);
        usuarioField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                usuarioFieldMousePressed(evt);
            }
        });
        fondoPrincipal.add(usuarioField);
        usuarioField.setBounds(60, 280, 310, 30);

        usuarioSeparador.setForeground(new java.awt.Color(0, 0, 0));
        fondoPrincipal.add(usuarioSeparador);
        usuarioSeparador.setBounds(60, 310, 310, 10);

        contraseñaLabel.setFont(new java.awt.Font("Roboto Light", 0, 14)); // NOI18N
        contraseñaLabel.setText("Contraseña.");
        fondoPrincipal.add(contraseñaLabel);
        contraseñaLabel.setBounds(60, 330, 80, 20);

        contraseñaField.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        contraseñaField.setForeground(new java.awt.Color(204, 204, 204));
        contraseñaField.setText("********");
        contraseñaField.setBorder(null);
        contraseñaField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                contraseñaFieldMousePressed(evt);
            }
        });
        fondoPrincipal.add(contraseñaField);
        contraseñaField.setBounds(60, 360, 310, 30);

        contraseñaSeparador.setForeground(new java.awt.Color(0, 0, 0));
        fondoPrincipal.add(contraseñaSeparador);
        contraseñaSeparador.setBounds(60, 390, 310, 10);
        fondoPrincipal.add(logoMainLabel);
        logoMainLabel.setBounds(80, 50, 100, 100);
        fondoPrincipal.add(loginStartImage);
        loginStartImage.setBounds(500, 0, 300, 500);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        entrarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        entrarButtonPanel.setLayout(null);

        entrarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        entrarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        entrarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        entrarButtonLabel.setText("Entrar");
        entrarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                entrarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                entrarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                entrarButtonLabelMouseExited(evt);
            }
        });
        entrarButtonPanel.add(entrarButtonLabel);
        entrarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(entrarButtonPanel);
        entrarButtonPanel.setBounds(70, 440, 100, 30);

        registrarseButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        registrarseButtonPanel.setLayout(null);

        registrarseButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        registrarseButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        registrarseButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        registrarseButtonLabel.setText("Registrarse");
        registrarseButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseExited(evt);
            }
        });
        registrarseButtonPanel.add(registrarseButtonLabel);
        registrarseButtonLabel.setBounds(0, 0, 130, 30);

        fondoPrincipal.add(registrarseButtonPanel);
        registrarseButtonPanel.setBounds(290, 440, 130, 30);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void usuarioFieldMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usuarioFieldMousePressed
        if (usuarioField.getText().equals("Ingrese su nombre de usuario.")) {
            usuarioField.setText("");
            usuarioField.setForeground(Color.black);
        }
        if (String.valueOf(contraseñaField.getPassword()).isEmpty()) {
            contraseñaField.setText("********");
            contraseñaField.setForeground(Color.gray);
        }
    }//GEN-LAST:event_usuarioFieldMousePressed

    private void contraseñaFieldMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contraseñaFieldMousePressed
        if (String.valueOf(contraseñaField.getPassword()).equals("********")) {
            contraseñaField.setText("");
            contraseñaField.setForeground(Color.black);
        }
        if (usuarioField.getText().isEmpty()) {
            usuarioField.setText("Ingrese su nombre de usuario.");
            usuarioField.setForeground(Color.gray);
        }
    }//GEN-LAST:event_contraseñaFieldMousePressed

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
        //System.out.println("Posición de x en pantalla principal: "+x);
        //System.out.println("Esta es la resta: "+(x - xMouse));
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
        //System.out.println("Aquí presioné el mouse por primera vez :"+xMouse);
    }//GEN-LAST:event_headerPanelMousePressed

    private void entrarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_entrarButtonLabelMouseEntered
        entrarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_entrarButtonLabelMouseEntered

    private void entrarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_entrarButtonLabelMouseExited
        entrarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_entrarButtonLabelMouseExited

    private void registrarseButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseEntered
        registrarseButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_registrarseButtonLabelMouseEntered

    private void registrarseButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseExited
        registrarseButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_registrarseButtonLabelMouseExited

    private void entrarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_entrarButtonLabelMouseClicked
        
        //Conectar la base de datos.
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        //Inicio de sesion.
        String privilegiosUsuarioString="";
        int privilegiosUsuarioInt=0;
        String idCliente="";
        String nombre=usuarioField.getText();
        String contraseña=String.valueOf(contraseñaField.getPassword());
        
        claseClientes c=new claseClientes();
        c.setNombreCliente(usuarioField.getText());
        c.setContraseñaCliente(String.valueOf(contraseñaField.getPassword()));
        
        claseEmpleados e=new claseEmpleados();
        e.setNombreEmpleado(usuarioField.getText());
        e.setContraseñaEmpleado(String.valueOf(contraseñaField.getPassword()));
        
        //Clientes.
        if(cBD.comprobarNombreCliente(c)==1){
            if(cBD.comprobarContraseñaCliente(c)==1){
                privilegiosUsuarioString="Cliente.";
                privilegiosUsuarioInt=1;
                idCliente=String.valueOf(cBD.encontrarIdCliente(usuarioField.getText(),String.valueOf(contraseñaField.getPassword())));
                
            }
            }
        
        //Empleados.
        if(cBD.comprobarNombreEmpleado(e)==1){
            if(cBD.comprobarContraseñaEmpleado(e)==1){
                privilegiosUsuarioString="Empleado.";
                privilegiosUsuarioInt=1;
            }
        }
        
        //Administrador.
        if(cBD.comprobarNombreAdministrador(usuarioField.getText())==1){
            if(cBD.comprobarContraseñaAdministrador(String.valueOf(contraseñaField.getPassword()))==1){
                privilegiosUsuarioString="Administrador.";
                privilegiosUsuarioInt=1;
            }
        }
        
        //Diferentes privilegios.
        if(privilegiosUsuarioInt==0){
            JOptionPane.showMessageDialog(null,"El nombre o la contraseña son incorrectos.");
        }

        if(privilegiosUsuarioInt!=0){
            JOptionPane.showMessageDialog(null,"Ha iniciado sesión con éxito.");
                this.dispose();
                menuDinamico mD=new menuDinamico();
                mD.setVisible(true);
                mD.Cambio(privilegiosUsuarioString, idCliente);
        }
        
    }//GEN-LAST:event_entrarButtonLabelMouseClicked

    private void registrarseButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseClicked
        this.dispose();
        registroClientes rC=new registroClientes();
        rC.setVisible(true);
    }//GEN-LAST:event_registrarseButtonLabelMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new inicioSesion().setVisible(true);
            }
        });
    }
    
    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoMainLabel.getWidth(), logoMainLabel.getHeight(), Image.SCALE_DEFAULT));
            logoMainLabel.setIcon(icono);
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\loginStart.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(loginStartImage.getWidth(), loginStartImage.getHeight(), Image.SCALE_DEFAULT));
            loginStartImage.setIcon(icono);
        }catch(IOException e){}
    }
            
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField contraseñaField;
    private javax.swing.JLabel contraseñaLabel;
    private javax.swing.JSeparator contraseñaSeparador;
    private javax.swing.JLabel entrarButtonLabel;
    private javax.swing.JPanel entrarButtonPanel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel inicioSesionLabel;
    private javax.swing.JLabel loginStartImage;
    private javax.swing.JLabel logoMainLabel;
    private javax.swing.JLabel registrarseButtonLabel;
    private javax.swing.JPanel registrarseButtonPanel;
    private javax.swing.JLabel tituloLabel;
    private javax.swing.JTextField usuarioField;
    private javax.swing.JLabel usuarioLabel;
    private javax.swing.JSeparator usuarioSeparador;
    // End of variables declaration//GEN-END:variables
}