package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;

public class menuDinamico extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public menuDinamico() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        tituloLabel = new javax.swing.JLabel();
        cuentaButtonLabel = new javax.swing.JLabel();
        pedidosButtonLabel = new javax.swing.JLabel();
        pedidosLabel = new javax.swing.JLabel();
        contactosButtonLabel = new javax.swing.JLabel();
        cuentaLabel = new javax.swing.JLabel();
        contactosLabel = new javax.swing.JLabel();
        catalogoButtonLabel = new javax.swing.JLabel();
        catalogoLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        mostrarUsuarioPanel = new javax.swing.JPanel();
        mostrarUsuarioLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        logoLabel.setText("jLabel1");
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Menú");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(380, 80, 220, 50);

        cuentaButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cuentaButtonLabelMouseClicked(evt);
            }
        });
        fondoPrincipal.add(cuentaButtonLabel);
        cuentaButtonLabel.setBounds(100, 330, 70, 70);

        pedidosButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pedidosButtonLabelMouseClicked(evt);
            }
        });
        fondoPrincipal.add(pedidosButtonLabel);
        pedidosButtonLabel.setBounds(100, 220, 70, 70);

        pedidosLabel.setFont(new java.awt.Font("Roboto", 0, 24)); // NOI18N
        pedidosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pedidosLabel.setText("En espera...");
        fondoPrincipal.add(pedidosLabel);
        pedidosLabel.setBounds(170, 230, 160, 50);

        contactosButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contactosButtonLabelMouseClicked(evt);
            }
        });
        fondoPrincipal.add(contactosButtonLabel);
        contactosButtonLabel.setBounds(460, 330, 70, 70);

        cuentaLabel.setFont(new java.awt.Font("Roboto", 0, 24)); // NOI18N
        cuentaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cuentaLabel.setText("En espera...");
        fondoPrincipal.add(cuentaLabel);
        cuentaLabel.setBounds(170, 340, 160, 50);

        contactosLabel.setFont(new java.awt.Font("Roboto", 0, 24)); // NOI18N
        contactosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        contactosLabel.setText("En espera...");
        fondoPrincipal.add(contactosLabel);
        contactosLabel.setBounds(530, 340, 150, 50);

        catalogoButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                catalogoButtonLabelMouseClicked(evt);
            }
        });
        fondoPrincipal.add(catalogoButtonLabel);
        catalogoButtonLabel.setBounds(460, 220, 70, 70);

        catalogoLabel.setFont(new java.awt.Font("Roboto", 0, 24)); // NOI18N
        catalogoLabel.setText("En espera...");
        fondoPrincipal.add(catalogoLabel);
        catalogoLabel.setBounds(530, 230, 260, 50);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        mostrarUsuarioPanel.setBackground(new java.awt.Color(0, 168, 234));
        mostrarUsuarioPanel.setLayout(null);

        mostrarUsuarioLabel.setBackground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        mostrarUsuarioLabel.setForeground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrarUsuarioLabel.setText("En espera...");
        mostrarUsuarioPanel.add(mostrarUsuarioLabel);
        mostrarUsuarioLabel.setBounds(0, 0, 160, 30);

        headerPanel.add(mostrarUsuarioPanel);
        mostrarUsuarioPanel.setBounds(620, 20, 160, 30);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(70, 440, 100, 30);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        inicioSesion iS=new inicioSesion();
        iS.setVisible(true);
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    private void catalogoButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_catalogoButtonLabelMouseClicked
        this.dispose();
        if(mostrarUsuarioLabel.getText().equals("Empleado.") || mostrarUsuarioLabel.getText().equals("Administrador.")){
            gestionarCatalogo gC=new gestionarCatalogo();
            gC.setVisible(true);
            gC.obtenerDatos(mostrarUsuarioLabel.getText());
        }else{
            tablaDinamica tD=new tablaDinamica();
        tD.setVisible(true);
        tD.obtenerDatos(mostrarUsuarioLabel.getText());
        }
    }//GEN-LAST:event_catalogoButtonLabelMouseClicked

    private void contactosButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contactosButtonLabelMouseClicked
                switch(mostrarUsuarioLabel.getText()){
            
            case "Administrador.":
            registroEmpleados rE=new registroEmpleados();
            rE.setVisible(true);
            rE.obtenerDatos(mostrarUsuarioLabel.getText());
            this.dispose();
                break;
                
            case "Empleado.":
                contactosNature cN=new contactosNature();
                cN.setVisible(true);
                cN.obtenerDatos(mostrarUsuarioLabel.getText());
                this.dispose();
                break;
            default:
                contactosNature cN2=new contactosNature();
                cN2.setVisible(true);
                cN2.obtenerDatos(mostrarUsuarioLabel.getText());
                this.dispose();
                break;
        }
    }//GEN-LAST:event_contactosButtonLabelMouseClicked

    private void pedidosButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pedidosButtonLabelMouseClicked
        this.dispose();
        consultarPedidos cP=new consultarPedidos();
        cP.setVisible(true);
        cP.obtenerDatos(mostrarUsuarioLabel.getText());
    }//GEN-LAST:event_pedidosButtonLabelMouseClicked

    private void cuentaButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cuentaButtonLabelMouseClicked
        modificarCliente mC=new modificarCliente();
        mC.setVisible(true);
        mC.obtenerDatos(mostrarUsuarioLabel.getText());
        this.dispose();
    }//GEN-LAST:event_cuentaButtonLabelMouseClicked

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menuDinamico().setVisible(true);
            }
        });
    }

    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\cuentaImagen.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(cuentaButtonLabel.getWidth(), cuentaButtonLabel.getHeight(), Image.SCALE_DEFAULT));
            cuentaButtonLabel.setIcon(icono);
            cuentaButtonLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\pedidosImagen.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(pedidosButtonLabel.getWidth(), pedidosButtonLabel.getHeight(), Image.SCALE_DEFAULT));
            pedidosButtonLabel.setIcon(icono);
            pedidosButtonLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\contactosImagen.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(contactosButtonLabel.getWidth(), contactosButtonLabel.getHeight(), Image.SCALE_DEFAULT));
            contactosButtonLabel.setIcon(icono);
            contactosButtonLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
        
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\catalogoImagen.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(catalogoButtonLabel.getWidth(), catalogoButtonLabel.getHeight(), Image.SCALE_DEFAULT));
            catalogoButtonLabel.setIcon(icono);
            catalogoButtonLabel.setCursor(new Cursor(HAND_CURSOR));
        }catch(IOException e){}
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }
    
    public void Cambio(String i, String id){
        switch(i){
            case "Cliente.":
                mostrarUsuarioLabel.setText(id);
                pedidosLabel.setText("Mis pedidos.");
                catalogoLabel.setText("Comprar.");
                cuentaLabel.setText("Mi cuenta.");
                contactosLabel.setText("Contactos.");
            break;
            
            case "Empleado.":
                mostrarUsuarioLabel.setText("Empleado.");
                pedidosLabel.setText("Ver pedidos.");
                catalogoLabel.setText("Gestionar catálogo.");
                cuentaLabel.setVisible(false);
                cuentaButtonLabel.setVisible(false); 
                contactosLabel.setText("Contactos.");
                contactosButtonLabel.setLocation(300, 330);
                contactosLabel.setLocation(370, 340);
                break;
                
            case "Administrador.":
                mostrarUsuarioLabel.setText("Administrador.");
                pedidosLabel.setText("Ver pedidos.");
                catalogoLabel.setText("Gestionar catálogo.");
                contactosLabel.setText("Empleados.");
                cuentaLabel.setVisible(false);
                cuentaButtonLabel.setVisible(false); 
                contactosButtonLabel.setLocation(300, 330);
                contactosLabel.setLocation(370, 340);
                break;
        }
    }
    
    public void obtenerDatos(String i){
        mostrarUsuarioLabel.setText(i);
    }
    
    public int obtenerIdCliente(int i){
        return i;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel catalogoButtonLabel;
    private javax.swing.JLabel catalogoLabel;
    private javax.swing.JLabel contactosButtonLabel;
    private javax.swing.JLabel contactosLabel;
    private javax.swing.JLabel cuentaButtonLabel;
    private javax.swing.JLabel cuentaLabel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel mostrarUsuarioLabel;
    private javax.swing.JPanel mostrarUsuarioPanel;
    private javax.swing.JLabel pedidosButtonLabel;
    private javax.swing.JLabel pedidosLabel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JLabel tituloLabel;
    // End of variables declaration//GEN-END:variables
}