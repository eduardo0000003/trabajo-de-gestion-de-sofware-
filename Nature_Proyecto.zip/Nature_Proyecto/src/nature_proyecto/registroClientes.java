package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;

public class registroClientes extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public registroClientes() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sexoButtonGroup = new javax.swing.ButtonGroup();
        fondoPrincipal = new javax.swing.JPanel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        logoLabel = new javax.swing.JLabel();
        tituloLabel = new javax.swing.JLabel();
        usuarioLabell = new javax.swing.JLabel();
        sexoLabel = new javax.swing.JLabel();
        registraUsuarioLabel = new javax.swing.JLabel();
        domicilioLabel = new javax.swing.JLabel();
        correoLabel = new javax.swing.JLabel();
        telefonoLabel = new javax.swing.JLabel();
        contraseñaLabel = new javax.swing.JLabel();
        usuarioField = new javax.swing.JTextField();
        masculinoRadioButton = new javax.swing.JRadioButton();
        femeninoRadioButton = new javax.swing.JRadioButton();
        diaComboBox = new javax.swing.JComboBox<>();
        mesComboBox = new javax.swing.JComboBox<>();
        añoComboBox = new javax.swing.JComboBox<>();
        domicilioField = new javax.swing.JTextField();
        correoField = new javax.swing.JTextField();
        contraseñaField = new javax.swing.JTextField();
        telefonoField = new javax.swing.JTextField();
        registrarseButtonPanel = new javax.swing.JPanel();
        registrarseButtonLabel = new javax.swing.JLabel();
        reiniciarFormularioButtonPanel = new javax.swing.JPanel();
        reiniciarFormularioButtonLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        fechaNacimientoLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Theo Vital");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(380, 80, 220, 50);

        usuarioLabell.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        usuarioLabell.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usuarioLabell.setText("Nombre:");
        fondoPrincipal.add(usuarioLabell);
        usuarioLabell.setBounds(60, 220, 60, 20);

        sexoLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        sexoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sexoLabel.setText("Sexo:");
        fondoPrincipal.add(sexoLabel);
        sexoLabel.setBounds(60, 270, 40, 19);

        registraUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        registraUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        registraUsuarioLabel.setText("Registra tu usuario");
        fondoPrincipal.add(registraUsuarioLabel);
        registraUsuarioLabel.setBounds(320, 170, 180, 24);

        domicilioLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        domicilioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        domicilioLabel.setText("Domicilio:");
        fondoPrincipal.add(domicilioLabel);
        domicilioLabel.setBounds(380, 320, 70, 20);

        correoLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        correoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        correoLabel.setText("Correo electrónico:");
        fondoPrincipal.add(correoLabel);
        correoLabel.setBounds(60, 320, 120, 20);

        telefonoLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        telefonoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        telefonoLabel.setText("Número telefónico:");
        fondoPrincipal.add(telefonoLabel);
        telefonoLabel.setBounds(380, 270, 120, 20);

        contraseñaLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        contraseñaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        contraseñaLabel.setText("Contraseña:");
        fondoPrincipal.add(contraseñaLabel);
        contraseñaLabel.setBounds(60, 370, 80, 20);

        usuarioField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(usuarioField);
        usuarioField.setBounds(130, 220, 190, 20);

        sexoButtonGroup.add(masculinoRadioButton);
        masculinoRadioButton.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        masculinoRadioButton.setText("Masculino.");
        fondoPrincipal.add(masculinoRadioButton);
        masculinoRadioButton.setBounds(120, 270, 90, 21);

        sexoButtonGroup.add(femeninoRadioButton);
        femeninoRadioButton.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        femeninoRadioButton.setText("Femenino.");
        fondoPrincipal.add(femeninoRadioButton);
        femeninoRadioButton.setBounds(230, 270, 93, 21);

        diaComboBox.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        diaComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        fondoPrincipal.add(diaComboBox);
        diaComboBox.setBounds(530, 220, 70, 22);

        mesComboBox.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        mesComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }));
        fondoPrincipal.add(mesComboBox);
        mesComboBox.setBounds(620, 220, 70, 22);

        añoComboBox.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        añoComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016" }));
        fondoPrincipal.add(añoComboBox);
        añoComboBox.setBounds(710, 220, 60, 22);

        domicilioField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(domicilioField);
        domicilioField.setBounds(460, 320, 300, 22);

        correoField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(correoField);
        correoField.setBounds(190, 320, 140, 22);

        contraseñaField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(contraseñaField);
        contraseñaField.setBounds(160, 370, 170, 20);

        telefonoField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(telefonoField);
        telefonoField.setBounds(510, 270, 180, 22);

        registrarseButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        registrarseButtonPanel.setLayout(null);

        registrarseButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        registrarseButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        registrarseButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        registrarseButtonLabel.setText("Registrarse.");
        registrarseButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseExited(evt);
            }
        });
        registrarseButtonPanel.add(registrarseButtonLabel);
        registrarseButtonLabel.setBounds(0, 0, 130, 30);

        fondoPrincipal.add(registrarseButtonPanel);
        registrarseButtonPanel.setBounds(570, 440, 130, 30);

        reiniciarFormularioButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        reiniciarFormularioButtonPanel.setLayout(null);

        reiniciarFormularioButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        reiniciarFormularioButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        reiniciarFormularioButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reiniciarFormularioButtonLabel.setText("Reiniciar formulario.");
        reiniciarFormularioButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reiniciarFormularioButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                reiniciarFormularioButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                reiniciarFormularioButtonLabelMouseExited(evt);
            }
        });
        reiniciarFormularioButtonPanel.add(reiniciarFormularioButtonLabel);
        reiniciarFormularioButtonLabel.setBounds(0, 0, 190, 30);

        fondoPrincipal.add(reiniciarFormularioButtonPanel);
        reiniciarFormularioButtonPanel.setBounds(300, 440, 190, 30);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(70, 440, 100, 30);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        fechaNacimientoLabel1.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        fechaNacimientoLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaNacimientoLabel1.setText("Fecha de nacimiento:");
        fondoPrincipal.add(fechaNacimientoLabel1);
        fechaNacimientoLabel1.setBounds(380, 220, 140, 19);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void registrarseButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseEntered
        registrarseButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_registrarseButtonLabelMouseEntered

    private void registrarseButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseExited
        registrarseButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_registrarseButtonLabelMouseExited

    private void reiniciarFormularioButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reiniciarFormularioButtonLabelMouseEntered
        reiniciarFormularioButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_reiniciarFormularioButtonLabelMouseEntered

    private void reiniciarFormularioButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reiniciarFormularioButtonLabelMouseExited
        reiniciarFormularioButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_reiniciarFormularioButtonLabelMouseExited

    private void reiniciarFormularioButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reiniciarFormularioButtonLabelMouseClicked
        usuarioField.setText(null);
        correoField.setText(null);
        contraseñaField.setText(null);
        sexoButtonGroup.clearSelection();
        diaComboBox.setSelectedIndex(0);
        mesComboBox.setSelectedIndex(0);
        añoComboBox.setSelectedIndex(0);
        telefonoField.setText(null);
        domicilioField.setText(null);
    }//GEN-LAST:event_reiniciarFormularioButtonLabelMouseClicked

    private void registrarseButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        claseClientes c=new claseClientes();
        c.setIdCliente(String.valueOf(cBD.idUnicaCliente()));
        c.setNombreCliente(usuarioField.getText());
        c.setCorreoCliente(correoField.getText());
        c.setContraseñaCliente(contraseñaField.getText());
        if(masculinoRadioButton.isSelected()){
            c.setSexoCliente("Masculino");
        }
        if(femeninoRadioButton.isSelected()){
            c.setSexoCliente("Femenino");
        }
        c.setFechaNacimientoCliente(String.valueOf(diaComboBox.getSelectedItem())
                +"/"+String.valueOf(mesComboBox.getSelectedItem())+"/"+String.valueOf(añoComboBox.getSelectedItem()));
        c.setTelefonoCliente(telefonoField.getText());
        c.setDireccionCliente(domicilioField.getText());
        cBD.registrarUsuario(c);
    }//GEN-LAST:event_registrarseButtonLabelMouseClicked

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        inicioSesion iS=new inicioSesion();
        iS.setVisible(true);
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroClientes().setVisible(true);
            }
        });
    }

    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
        
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> añoComboBox;
    private javax.swing.JTextField contraseñaField;
    private javax.swing.JLabel contraseñaLabel;
    private javax.swing.JTextField correoField;
    private javax.swing.JLabel correoLabel;
    private javax.swing.JComboBox<String> diaComboBox;
    private javax.swing.JTextField domicilioField;
    private javax.swing.JLabel domicilioLabel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JLabel fechaNacimientoLabel1;
    private javax.swing.JRadioButton femeninoRadioButton;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JRadioButton masculinoRadioButton;
    private javax.swing.JComboBox<String> mesComboBox;
    private javax.swing.JLabel registraUsuarioLabel;
    private javax.swing.JLabel registrarseButtonLabel;
    private javax.swing.JPanel registrarseButtonPanel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JLabel reiniciarFormularioButtonLabel;
    private javax.swing.JPanel reiniciarFormularioButtonPanel;
    private javax.swing.ButtonGroup sexoButtonGroup;
    private javax.swing.JLabel sexoLabel;
    private javax.swing.JTextField telefonoField;
    private javax.swing.JLabel telefonoLabel;
    private javax.swing.JLabel tituloLabel;
    private javax.swing.JTextField usuarioField;
    private javax.swing.JLabel usuarioLabell;
    // End of variables declaration//GEN-END:variables
}