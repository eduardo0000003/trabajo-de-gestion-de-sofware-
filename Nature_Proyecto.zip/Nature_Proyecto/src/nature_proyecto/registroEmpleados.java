package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;

public class registroEmpleados extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public registroEmpleados() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        usuarioLabell = new javax.swing.JLabel();
        cargoLabel = new javax.swing.JLabel();
        contraseñaLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        usuarioField = new javax.swing.JTextField();
        contraseñaField = new javax.swing.JTextField();
        cargoField = new javax.swing.JTextField();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        mostrarUsuarioPanel = new javax.swing.JPanel();
        mostrarUsuarioLabel = new javax.swing.JLabel();
        registrarseButtonPanel = new javax.swing.JPanel();
        registrarseButtonLabel = new javax.swing.JLabel();
        reiniciarFormularioButtonPanel = new javax.swing.JPanel();
        reiniciarFormularioButtonLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();
        tituloLabel1 = new javax.swing.JLabel();
        pedidosLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        usuarioLabell.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        usuarioLabell.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        usuarioLabell.setText("Nombre:");
        fondoPrincipal.add(usuarioLabell);
        usuarioLabell.setBounds(250, 250, 60, 20);

        cargoLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        cargoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cargoLabel.setText("Cargo:");
        fondoPrincipal.add(cargoLabel);
        cargoLabel.setBounds(210, 370, 120, 20);

        contraseñaLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        contraseñaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        contraseñaLabel.setText("Contraseña:");
        fondoPrincipal.add(contraseñaLabel);
        contraseñaLabel.setBounds(250, 310, 80, 20);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        usuarioField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(usuarioField);
        usuarioField.setBounds(310, 250, 210, 20);

        contraseñaField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(contraseñaField);
        contraseñaField.setBounds(340, 310, 180, 20);

        cargoField.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fondoPrincipal.add(cargoField);
        cargoField.setBounds(300, 370, 220, 22);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        mostrarUsuarioPanel.setBackground(new java.awt.Color(0, 168, 234));
        mostrarUsuarioPanel.setLayout(null);

        mostrarUsuarioLabel.setBackground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        mostrarUsuarioLabel.setForeground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrarUsuarioLabel.setText("En espera...");
        mostrarUsuarioPanel.add(mostrarUsuarioLabel);
        mostrarUsuarioLabel.setBounds(0, 0, 160, 30);

        headerPanel.add(mostrarUsuarioPanel);
        mostrarUsuarioPanel.setBounds(620, 20, 160, 30);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        registrarseButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        registrarseButtonPanel.setLayout(null);

        registrarseButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        registrarseButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        registrarseButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        registrarseButtonLabel.setText("Registrar.");
        registrarseButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                registrarseButtonLabelMouseExited(evt);
            }
        });
        registrarseButtonPanel.add(registrarseButtonLabel);
        registrarseButtonLabel.setBounds(0, 0, 130, 30);

        fondoPrincipal.add(registrarseButtonPanel);
        registrarseButtonPanel.setBounds(570, 440, 130, 30);

        reiniciarFormularioButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        reiniciarFormularioButtonPanel.setLayout(null);

        reiniciarFormularioButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        reiniciarFormularioButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        reiniciarFormularioButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        reiniciarFormularioButtonLabel.setText("Reiniciar formulario.");
        reiniciarFormularioButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reiniciarFormularioButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                reiniciarFormularioButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                reiniciarFormularioButtonLabelMouseExited(evt);
            }
        });
        reiniciarFormularioButtonPanel.add(reiniciarFormularioButtonLabel);
        reiniciarFormularioButtonLabel.setBounds(0, 0, 190, 30);

        fondoPrincipal.add(reiniciarFormularioButtonPanel);
        reiniciarFormularioButtonPanel.setBounds(300, 440, 190, 30);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(70, 440, 100, 30);

        tituloLabel1.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel1.setText("Theo Vital");
        fondoPrincipal.add(tituloLabel1);
        tituloLabel1.setBounds(380, 80, 220, 50);

        pedidosLabel.setFont(new java.awt.Font("Roboto", 0, 24)); // NOI18N
        pedidosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        pedidosLabel.setText("Registrar nuevos empleados");
        fondoPrincipal.add(pedidosLabel);
        pedidosLabel.setBounds(260, 160, 320, 50);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void registrarseButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();

        if(usuarioField.getText().isBlank() || cargoField.getText().isBlank() || contraseñaField.getText().isBlank()){
            JOptionPane.showMessageDialog(null,"Porfavor rellena los campos.");
        }else{
            claseEmpleados e=new claseEmpleados();
        e.setIdEmpleado(String.valueOf(cBD.idUnicaEmpleado()));
        e.setNombreEmpleado(usuarioField.getText());
        e.setCargoEmpleado(cargoField.getText());
        e.setContraseñaEmpleado(contraseñaField.getText());
        cBD.registrarEmpleado(e);
        }
    }//GEN-LAST:event_registrarseButtonLabelMouseClicked

    private void registrarseButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseEntered
        registrarseButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_registrarseButtonLabelMouseEntered

    private void registrarseButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarseButtonLabelMouseExited
        registrarseButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_registrarseButtonLabelMouseExited

    private void reiniciarFormularioButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reiniciarFormularioButtonLabelMouseClicked
        usuarioField.setText(null);
        contraseñaField.setText(null);
        cargoField.setText(null);
    }//GEN-LAST:event_reiniciarFormularioButtonLabelMouseClicked

    private void reiniciarFormularioButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reiniciarFormularioButtonLabelMouseEntered
        reiniciarFormularioButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_reiniciarFormularioButtonLabelMouseEntered

    private void reiniciarFormularioButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reiniciarFormularioButtonLabelMouseExited
        reiniciarFormularioButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_reiniciarFormularioButtonLabelMouseExited

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        menuDinamico mD=new menuDinamico();
        mD.Cambio(mostrarUsuarioLabel.getText(), "");
        mD.setVisible(true);
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new registroEmpleados().setVisible(true);
            }
        });
    }
    
    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
        
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }
    
    public void obtenerDatos(String i){
        mostrarUsuarioLabel.setText(i);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField cargoField;
    private javax.swing.JLabel cargoLabel;
    private javax.swing.JTextField contraseñaField;
    private javax.swing.JLabel contraseñaLabel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel mostrarUsuarioLabel;
    private javax.swing.JPanel mostrarUsuarioPanel;
    private javax.swing.JLabel pedidosLabel;
    private javax.swing.JLabel registrarseButtonLabel;
    private javax.swing.JPanel registrarseButtonPanel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JLabel reiniciarFormularioButtonLabel;
    private javax.swing.JPanel reiniciarFormularioButtonPanel;
    private javax.swing.JLabel tituloLabel1;
    private javax.swing.JTextField usuarioField;
    private javax.swing.JLabel usuarioLabell;
    // End of variables declaration//GEN-END:variables
}