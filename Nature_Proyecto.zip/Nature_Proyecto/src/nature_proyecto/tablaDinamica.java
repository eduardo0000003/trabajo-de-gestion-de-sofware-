package nature_proyecto;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;

public class tablaDinamica extends javax.swing.JFrame {

    int xMouse, yMouse;
    DefaultTableModel modelo=new DefaultTableModel();

    public tablaDinamica() {
        this.setUndecorated(true);
        initComponents();
        configuracionPantalla();
        configurarImagenes();
        fechaActual();
        inicializarTablas();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fondoPrincipal = new javax.swing.JPanel();
        logoLabel = new javax.swing.JLabel();
        tituloLabel = new javax.swing.JLabel();
        tablaDinamicaScroll = new javax.swing.JScrollPane();
        tablaDinamica = new javax.swing.JTable();
        categoriaLabel = new javax.swing.JLabel();
        fechaLabel = new javax.swing.JLabel();
        categoriaCombo = new javax.swing.JComboBox<>();
        elementosLabel = new javax.swing.JLabel();
        headerPanel = new javax.swing.JPanel();
        exitButtonPanel = new javax.swing.JPanel();
        exitButtonLabel = new javax.swing.JLabel();
        mostrarUsuarioPanel = new javax.swing.JPanel();
        mostrarUsuarioLabel = new javax.swing.JLabel();
        agregarButtonPanel = new javax.swing.JPanel();
        agregarButtonLabel = new javax.swing.JLabel();
        comprarButtonPanel = new javax.swing.JPanel();
        comprarButtonLabel = new javax.swing.JLabel();
        eliminarButtonPanel = new javax.swing.JPanel();
        eliminarButtonLabel = new javax.swing.JLabel();
        regresarButtonPanel = new javax.swing.JPanel();
        regresarButtonLabel = new javax.swing.JLabel();
        cantidadSpinner = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        carritoDinamico = new javax.swing.JTable();
        cantidadLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        fondoPrincipal.setBackground(new java.awt.Color(255, 255, 255));
        fondoPrincipal.setLayout(null);

        logoLabel.setText("jLabel1");
        fondoPrincipal.add(logoLabel);
        logoLabel.setBounds(260, 50, 100, 100);

        tituloLabel.setFont(new java.awt.Font("Roboto Thin", 0, 48)); // NOI18N
        tituloLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tituloLabel.setText("Comprar");
        fondoPrincipal.add(tituloLabel);
        tituloLabel.setBounds(380, 80, 220, 50);

        tablaDinamica.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        tablaDinamica.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        tablaDinamica.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre.", "Precio."
            }
        ));
        tablaDinamica.setGridColor(new java.awt.Color(0, 0, 0));
        tablaDinamicaScroll.setViewportView(tablaDinamica);

        fondoPrincipal.add(tablaDinamicaScroll);
        tablaDinamicaScroll.setBounds(40, 230, 420, 180);

        categoriaLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        categoriaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        categoriaLabel.setText("Selecciona una categoría:");
        fondoPrincipal.add(categoriaLabel);
        categoriaLabel.setBounds(80, 190, 180, 30);

        fechaLabel.setFont(new java.awt.Font("Roboto Thin", 0, 18)); // NOI18N
        fechaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fechaLabel.setText("Fecha.");
        fechaLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        fondoPrincipal.add(fechaLabel);
        fechaLabel.setBounds(620, 50, 160, 30);

        categoriaCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cremas corporales", "Shampoos", "Higiene dental" }));
        categoriaCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoriaComboActionPerformed(evt);
            }
        });
        fondoPrincipal.add(categoriaCombo);
        categoriaCombo.setBounds(260, 190, 180, 30);

        elementosLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        elementosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        elementosLabel.setText("Carrito:");
        fondoPrincipal.add(elementosLabel);
        elementosLabel.setBounds(550, 180, 190, 30);

        headerPanel.setBackground(new java.awt.Color(255, 255, 255));
        headerPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerPanelMouseDragged(evt);
            }
        });
        headerPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerPanelMousePressed(evt);
            }
        });
        headerPanel.setLayout(null);

        exitButtonPanel.setBackground(new java.awt.Color(255, 255, 255));
        exitButtonPanel.setLayout(null);

        exitButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        exitButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exitButtonLabel.setText("X");
        exitButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exitButtonLabelMouseExited(evt);
            }
        });
        exitButtonPanel.add(exitButtonLabel);
        exitButtonLabel.setBounds(0, 0, 50, 50);

        headerPanel.add(exitButtonPanel);
        exitButtonPanel.setBounds(0, 0, 50, 50);

        mostrarUsuarioPanel.setBackground(new java.awt.Color(0, 168, 234));
        mostrarUsuarioPanel.setLayout(null);

        mostrarUsuarioLabel.setBackground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        mostrarUsuarioLabel.setForeground(new java.awt.Color(255, 255, 255));
        mostrarUsuarioLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mostrarUsuarioLabel.setText("En espera...");
        mostrarUsuarioPanel.add(mostrarUsuarioLabel);
        mostrarUsuarioLabel.setBounds(0, 0, 160, 30);

        headerPanel.add(mostrarUsuarioPanel);
        mostrarUsuarioPanel.setBounds(620, 20, 160, 30);

        fondoPrincipal.add(headerPanel);
        headerPanel.setBounds(0, 0, 800, 50);

        agregarButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        agregarButtonPanel.setLayout(null);

        agregarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        agregarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        agregarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        agregarButtonLabel.setText("Agregar.");
        agregarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                agregarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                agregarButtonLabelMouseExited(evt);
            }
        });
        agregarButtonPanel.add(agregarButtonLabel);
        agregarButtonLabel.setBounds(0, 0, 90, 30);

        fondoPrincipal.add(agregarButtonPanel);
        agregarButtonPanel.setBounds(340, 440, 90, 30);

        comprarButtonPanel.setBackground(new java.awt.Color(0, 168, 234));
        comprarButtonPanel.setLayout(null);

        comprarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        comprarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        comprarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        comprarButtonLabel.setText("Comprar.");
        comprarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comprarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                comprarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                comprarButtonLabelMouseExited(evt);
            }
        });
        comprarButtonPanel.add(comprarButtonLabel);
        comprarButtonLabel.setBounds(0, 0, 90, 30);

        fondoPrincipal.add(comprarButtonPanel);
        comprarButtonPanel.setBounds(670, 440, 90, 30);

        eliminarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        eliminarButtonPanel.setLayout(null);

        eliminarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        eliminarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        eliminarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        eliminarButtonLabel.setText("Eliminar.");
        eliminarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                eliminarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                eliminarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                eliminarButtonLabelMouseExited(evt);
            }
        });
        eliminarButtonPanel.add(eliminarButtonLabel);
        eliminarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(eliminarButtonPanel);
        eliminarButtonPanel.setBounds(540, 440, 100, 30);

        regresarButtonPanel.setBackground(new java.awt.Color(0, 169, 237));
        regresarButtonPanel.setLayout(null);

        regresarButtonLabel.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        regresarButtonLabel.setForeground(new java.awt.Color(255, 255, 255));
        regresarButtonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        regresarButtonLabel.setText("Regresar");
        regresarButtonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                regresarButtonLabelMouseExited(evt);
            }
        });
        regresarButtonPanel.add(regresarButtonLabel);
        regresarButtonLabel.setBounds(0, 0, 100, 30);

        fondoPrincipal.add(regresarButtonPanel);
        regresarButtonPanel.setBounds(30, 440, 100, 30);

        cantidadSpinner.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        cantidadSpinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 99, 1));
        fondoPrincipal.add(cantidadSpinner);
        cantidadSpinner.setBounds(270, 440, 50, 30);

        carritoDinamico.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        carritoDinamico.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        carritoDinamico.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre.", "Cantidad.", "Precio."
            }
        ));
        jScrollPane1.setViewportView(carritoDinamico);

        fondoPrincipal.add(jScrollPane1);
        jScrollPane1.setBounds(520, 220, 260, 200);

        cantidadLabel.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        cantidadLabel.setText("Cantidad:");
        fondoPrincipal.add(cantidadLabel);
        cantidadLabel.setBounds(200, 450, 70, 20);

        getContentPane().add(fondoPrincipal);
        fondoPrincipal.setBounds(0, 0, 800, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exitButtonLabelMouseClicked

    private void exitButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseEntered
        exitButtonPanel.setBackground(Color.red);
        exitButtonLabel.setForeground(Color.white);
    }//GEN-LAST:event_exitButtonLabelMouseEntered

    private void exitButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitButtonLabelMouseExited
        exitButtonPanel.setBackground(Color.white);
        exitButtonLabel.setForeground(Color.black);
    }//GEN-LAST:event_exitButtonLabelMouseExited

    private void headerPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerPanelMouseDragged

    private void headerPanelMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerPanelMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerPanelMousePressed

    private void agregarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarButtonLabelMouseEntered
        agregarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_agregarButtonLabelMouseEntered

    private void agregarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarButtonLabelMouseExited
        agregarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_agregarButtonLabelMouseExited

    private void comprarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comprarButtonLabelMouseEntered
        comprarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_comprarButtonLabelMouseEntered

    private void comprarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comprarButtonLabelMouseExited
        comprarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_comprarButtonLabelMouseExited

    private void eliminarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarButtonLabelMouseClicked
        DefaultTableModel modeloVacio=new DefaultTableModel();
           modeloVacio.addColumn("Nombre.");
            modeloVacio.addColumn("Cantidad.");
            modeloVacio.addColumn("Precio.");
        carritoDinamico.setModel(modeloVacio);
        Object[] columnas=new Object[3];
        columnas[0]="Nombre.";
        columnas[1]="Cantidad";
        columnas[2]="Precio";
        Object[][] vacio=new Object[0][0];
        modelo.setDataVector(vacio, columnas);
        listaCarrito();
    }//GEN-LAST:event_eliminarButtonLabelMouseClicked

    private void eliminarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarButtonLabelMouseEntered
        eliminarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_eliminarButtonLabelMouseEntered

    private void eliminarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eliminarButtonLabelMouseExited
        eliminarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_eliminarButtonLabelMouseExited

    private void regresarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseClicked
        this.dispose();
        menuDinamico mD=new menuDinamico();
        mD.setVisible(true);
        mD.obtenerDatos(mostrarUsuarioLabel.getText());
        mD.Cambio("Cliente.", mostrarUsuarioLabel.getText());
    }//GEN-LAST:event_regresarButtonLabelMouseClicked

    private void regresarButtonLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseEntered
        regresarButtonPanel.setBackground(new Color(0, 156, 223));
    }//GEN-LAST:event_regresarButtonLabelMouseEntered

    private void regresarButtonLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_regresarButtonLabelMouseExited
        regresarButtonPanel.setBackground(new Color(0,171,239));
    }//GEN-LAST:event_regresarButtonLabelMouseExited

    private void categoriaComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoriaComboActionPerformed
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        DefaultTableModel modelo=new DefaultTableModel();
        tablaDinamica.setModel(modelo);
        ResultSet rs=cBD.mostrarProductos(String.valueOf(categoriaCombo.getSelectedItem()));
        try{
        ResultSetMetaData rsmd=rs.getMetaData();
        int columnas=rsmd.getColumnCount();
        modelo.addColumn("Nombre");
        modelo.addColumn("Precio.");
        while(rs.next()){
            Object [] filas=new Object [columnas];
            for(int i=0;i<columnas;i++){
                filas[i]=rs.getObject(i+1);
            }
            modelo.addRow(filas);
        }
    }catch(SQLException sqle){
        System.out.println(sqle.getMessage());
            sqle.printStackTrace();
    }
    }//GEN-LAST:event_categoriaComboActionPerformed

    private void agregarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarButtonLabelMouseClicked
        //Añadir.
        int fila=tablaDinamica.getSelectedRow();
        if(fila==-1){
            JOptionPane.showMessageDialog(null,"No has seleccionado un elemento.");
        }else{
            String nombre=tablaDinamica.getValueAt(fila, 0).toString();
            String precio=tablaDinamica.getValueAt(fila, 1).toString();
            JOptionPane.showMessageDialog(null,"Has agregado el elemento: "+nombre+" en una cantidad de: "+cantidadSpinner.getValue()+".");
            carritoDinamico.setModel(modelo);
            Object [] filas=new Object [3];
            filas[0]=nombre;
            filas[1]=cantidadSpinner.getValue();
            filas[2]=precio;
            modelo.addRow(filas);
            
            listaCarrito();
        }
    }//GEN-LAST:event_agregarButtonLabelMouseClicked

    private void comprarButtonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comprarButtonLabelMouseClicked
        conexionBD cBD=new conexionBD();
        cBD.conectar();
        
        int filasTablaActual=carritoDinamico.getRowCount();
        
        if(filasTablaActual==0){
            JOptionPane.showMessageDialog(null,"Añade objetos al carrito.");
        }else{
            //Declaración de variables y largo de la tabla.
            Object[] datosNombre=new Object[carritoDinamico.getRowCount()];
            Object[] datosCantidad=new Object[carritoDinamico.getRowCount()];
            Object[] datosPrecio=new Object[carritoDinamico.getRowCount()];
            
            //Obtener valores del carrito.
            
            for(int i=0;i<filasTablaActual;i++){
                datosNombre[i]=carritoDinamico.getValueAt(i, 0);
                datosCantidad[i]=carritoDinamico.getValueAt(i, 1);
                datosPrecio[i]=carritoDinamico.getValueAt(i, 2);
            }
            
            clasePedidos cP=new clasePedidos();
            
            cP.setIdPedido(String.valueOf(cBD.idUnicaPedido()));
            cP.setIdClientePedido(mostrarUsuarioLabel.getText());
            String descripcionPedido="";
            for(int i=0;i<filasTablaActual;i++){
                descripcionPedido+="Nombre: "+datosNombre[i]+".";
                descripcionPedido+="Cantidad: "+datosCantidad[i]+".";
                descripcionPedido+="Precio: "+datosPrecio[i]+".";
            }
            cP.setDescripcionPedido(descripcionPedido);
            int cuentaTotal=0;
            for(int i=0;i<filasTablaActual;i++){
                String cA=""+datosPrecio[i];
                String cantidad=""+datosCantidad[i];
                int cuentaActual=Integer.parseInt(cA)*Integer.parseInt(cantidad);
                cuentaTotal+=cuentaActual;
            }
            cP.setCostoPedido(String.valueOf(cuentaTotal));
            cP.setFechaPedido(fechaLabel.getText());
            
            cP.getIdPedido();
            cP.getIdClientePedido();
            cP.getDescripcionPedido();
            cP.getCostoPedido();
            cP.getFechaPedido();
            
            cBD.registrarPedido(cP);
        }   
    }//GEN-LAST:event_comprarButtonLabelMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tablaDinamica().setVisible(true);
            }
        });
    }

    public void configuracionPantalla(){
        this.setSize(800,500);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        exitButtonLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void configurarImagenes(){
        try{
            BufferedImage imagen=ImageIO.read(new File("src\\imagenes\\logoNature.png"));
            ImageIcon icono=new ImageIcon(imagen.getScaledInstance(logoLabel.getWidth(), logoLabel.getHeight(), Image.SCALE_DEFAULT));
            logoLabel.setIcon(icono);
        }catch(IOException e){}
        
    }
    
    public void fechaActual(){
        Calendar c=new GregorianCalendar();
        fechaLabel.setText(Integer.toString(c.get(Calendar.DATE))+"/"+Integer.toString(c.get(Calendar.MONTH)+1)+"/"+Integer.toString(c.get(Calendar.YEAR)));
    }
    
    public void obtenerDatos(String i){
        mostrarUsuarioLabel.setText(i);
    }
    
    public void listaCarrito(){
        //Declaración de variables y largo de la tabla.
            Object[] datosNombre=new Object[carritoDinamico.getRowCount()];
            Object[] datosCantidad=new Object[carritoDinamico.getRowCount()];
            Object[] datosPrecio=new Object[carritoDinamico.getRowCount()];
            int filasTablaActual=carritoDinamico.getRowCount();
            
            //Obtener valores del carrito.
            
            for(int i=0;i<filasTablaActual;i++){
                datosNombre[i]=carritoDinamico.getValueAt(i, 0);
                datosCantidad[i]=carritoDinamico.getValueAt(i, 1);
                datosPrecio[i]=carritoDinamico.getValueAt(i, 2);
            }
            
            //Establecer los valores en el carrito.
            for(int i=0;i<filasTablaActual;i++){
                carritoDinamico.setValueAt(datosNombre[i], i, 0);
                carritoDinamico.setValueAt(datosCantidad[i], i, 1);
                carritoDinamico.setValueAt(datosPrecio[i], i, 2);
            }
            
            //Mostrar.
            System.out.println("-------Nueva entrada-------");
            for(int i=0;i<filasTablaActual;i++){
                System.out.println("Nombre: "+datosNombre[i]);
                System.out.println("Cantidad: "+datosCantidad[i]);
                System.out.println("Precio: "+datosPrecio[i]);
                System.out.println("\n");
            }
    }
    
    public void inicializarTablas(){
        modelo.addColumn("Nombre.");
        modelo.addColumn("Cantidad.");
        modelo.addColumn("Precio.");
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel agregarButtonLabel;
    private javax.swing.JPanel agregarButtonPanel;
    private javax.swing.JLabel cantidadLabel;
    private javax.swing.JSpinner cantidadSpinner;
    private javax.swing.JTable carritoDinamico;
    private javax.swing.JComboBox<String> categoriaCombo;
    private javax.swing.JLabel categoriaLabel;
    private javax.swing.JLabel comprarButtonLabel;
    private javax.swing.JPanel comprarButtonPanel;
    private javax.swing.JLabel elementosLabel;
    private javax.swing.JLabel eliminarButtonLabel;
    private javax.swing.JPanel eliminarButtonPanel;
    private javax.swing.JLabel exitButtonLabel;
    private javax.swing.JPanel exitButtonPanel;
    private javax.swing.JLabel fechaLabel;
    private javax.swing.JPanel fondoPrincipal;
    private javax.swing.JPanel headerPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel logoLabel;
    private javax.swing.JLabel mostrarUsuarioLabel;
    private javax.swing.JPanel mostrarUsuarioPanel;
    private javax.swing.JLabel regresarButtonLabel;
    private javax.swing.JPanel regresarButtonPanel;
    private javax.swing.JTable tablaDinamica;
    private javax.swing.JScrollPane tablaDinamicaScroll;
    private javax.swing.JLabel tituloLabel;
    // End of variables declaration//GEN-END:variables
}